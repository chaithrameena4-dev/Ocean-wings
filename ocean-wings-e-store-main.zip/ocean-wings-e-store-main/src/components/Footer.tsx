import { Fish, MapPin, Phone, Mail } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-ocean-deep text-white mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Fish className="h-8 w-8 text-secondary" />
              <span className="text-xl font-bold">Ocean Wings</span>
            </div>
            <p className="text-sm text-ocean-light">
              Your trusted partner for premium aquarium products and expert advice.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/products" className="text-ocean-light hover:text-white transition-smooth">
                  Products
                </Link>
              </li>
              <li>
                <Link to="/gallery" className="text-ocean-light hover:text-white transition-smooth">
                  Gallery
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-ocean-light hover:text-white transition-smooth">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-ocean-light hover:text-white transition-smooth">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-4">Categories</h3>
            <ul className="space-y-2 text-sm">
              <li className="text-ocean-light">Aquarium Tanks</li>
              <li className="text-ocean-light">Fishes</li>
              <li className="text-ocean-light">Foods & Accessories</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start space-x-2">
                <MapPin className="h-4 w-4 mt-1 flex-shrink-0 text-secondary" />
                <span className="text-ocean-light">
                  Ocean Wings, Horamaru, Near Underpass, Opp Dry Fruits Shop, Bengaluru – 560043
                </span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-secondary" />
                <a href="tel:+919738151348" className="text-ocean-light hover:text-white transition-smooth">
                  +91 9738151348
                </a>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-secondary" />
                <span className="text-ocean-light">oceanwings@example.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-ocean-light/20 mt-8 pt-8 text-center text-sm text-ocean-light">
          <p>&copy; {new Date().getFullYear()} Ocean Wings Aquarium. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
