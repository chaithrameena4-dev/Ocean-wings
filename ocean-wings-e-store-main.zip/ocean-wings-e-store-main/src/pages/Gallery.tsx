import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Gallery = () => {
  // Placeholder gallery items - can be replaced with real images
  const galleryItems = [
    { title: "Tropical Paradise Tank", description: "Vibrant tropical fish setup" },
    { title: "Reef Aquarium", description: "Stunning coral reef display" },
    { title: "Planted Tank", description: "Lush aquascaping design" },
    { title: "Community Tank", description: "Peaceful community fish" },
    { title: "Nano Tank", description: "Compact aquarium setup" },
    { title: "Custom Design", description: "Bespoke aquarium creation" },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-ocean text-white py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Gallery</h1>
          <p className="text-xl text-white/90">
            Explore beautiful aquarium setups and inspiration
          </p>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 flex-1">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryItems.map((item, index) => (
              <Card key={index} className="shadow-card hover:shadow-ocean transition-smooth overflow-hidden group">
                <CardContent className="p-0">
                  <div className="aspect-video bg-gradient-wave flex items-center justify-center text-white text-6xl group-hover:scale-110 transition-smooth">
                    🐠
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-muted-foreground">{item.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Gallery;
