import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Fish, Droplets, Heart, ShoppingBag, Star, TrendingUp } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Home = () => {
  const features = [
    {
      icon: Fish,
      title: "Premium Quality Fish",
      description: "Healthy, vibrant fish from trusted breeders worldwide",
    },
    {
      icon: Droplets,
      title: "Expert Water Solutions",
      description: "Complete filtration and water treatment systems",
    },
    {
      icon: Heart,
      title: "Passionate Care",
      description: "Expert advice and support for your aquarium journey",
    },
    {
      icon: ShoppingBag,
      title: "One-Stop Shop",
      description: "Everything you need for a thriving aquarium",
    },
  ];

  const categories = [
    {
      title: "Aquarium Tanks",
      description: "Glass tanks, nano tanks, and custom designs",
      image: "🏺",
      link: "/products?category=tanks",
    },
    {
      title: "Fishes",
      description: "Freshwater, saltwater, and rare species",
      image: "🐠",
      link: "/products?category=fishes",
    },
    {
      title: "Foods & Accessories",
      description: "Fish food, filters, pumps, and more",
      image: "🎨",
      link: "/products?category=accessories",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-ocean-wave to-secondary py-20 md:py-32">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl float-animation"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-secondary rounded-full blur-3xl float-animation" style={{ animationDelay: '2s' }}></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
              Welcome to Ocean Wings Aquarium
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-white/90 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Your Premier Destination for Aquatic Excellence
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <Link to="/products">
                <Button size="lg" className="bg-white text-primary hover:bg-white/90 shadow-ocean">
                  Explore Products
                </Button>
              </Link>
              <Link to="/contact">
                <Button size="lg" variant="outline" className="bg-white/10 border-white text-white hover:bg-white/20">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Why Choose Ocean Wings?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="shadow-card hover:shadow-ocean transition-smooth hover:scale-105 border-border/50">
                <CardContent className="pt-6 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                    <feature.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 md:py-24 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Explore Our Categories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <Link key={index} to={category.link}>
                <Card className="shadow-card hover:shadow-ocean transition-smooth hover:scale-105 cursor-pointer h-full border-border/50">
                  <CardContent className="pt-6 text-center">
                    <div className="text-6xl mb-4">{category.image}</div>
                    <h3 className="text-2xl font-semibold mb-2">{category.title}</h3>
                    <p className="text-muted-foreground mb-4">{category.description}</p>
                    <Button className="gradient-ocean">
                      View Products
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 md:py-24 bg-gradient-ocean text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="flex items-center justify-center mb-2">
                <Star className="h-8 w-8 mr-2" />
                <div className="text-4xl font-bold">500+</div>
              </div>
              <p className="text-xl text-white/90">Happy Customers</p>
            </div>
            <div>
              <div className="flex items-center justify-center mb-2">
                <Fish className="h-8 w-8 mr-2" />
                <div className="text-4xl font-bold">200+</div>
              </div>
              <p className="text-xl text-white/90">Fish Species</p>
            </div>
            <div>
              <div className="flex items-center justify-center mb-2">
                <TrendingUp className="h-8 w-8 mr-2" />
                <div className="text-4xl font-bold">5+</div>
              </div>
              <p className="text-xl text-white/90">Years Experience</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <Card className="shadow-ocean border-0 gradient-wave">
            <CardContent className="py-12 text-center text-white">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Start Your Aquarium Journey?
              </h2>
              <p className="text-xl mb-8 text-white/90">
                Visit us today or browse our collection online
              </p>
              <Link to="/products">
                <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                  Shop Now
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Home;
