import { Card, CardContent } from "@/components/ui/card";
import { Award, Heart, Users, TrendingUp } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const About = () => {
  const values = [
    {
      icon: Heart,
      title: "Passion",
      description: "Deep love for aquatic life drives everything we do",
    },
    {
      icon: Award,
      title: "Quality",
      description: "Only the finest products for your aquarium",
    },
    {
      icon: Users,
      title: "Community",
      description: "Building lasting relationships with our customers",
    },
    {
      icon: TrendingUp,
      title: "Growth",
      description: "Continuously expanding our knowledge and offerings",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-ocean text-white py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Us</h1>
          <p className="text-xl text-white/90">
            Your trusted aquarium partner since 2019
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <Card className="shadow-ocean">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="prose prose-lg max-w-none text-muted-foreground space-y-4">
                <p>
                  Founded in 2019, Ocean Wings Aquarium has been serving the Bengaluru community with
                  premium aquarium products and expert guidance. What started as a small shop has grown
                  into a trusted destination for aquarium enthusiasts across the region.
                </p>
                <p>
                  Located in Horamaru, near the underpass opposite the dry fruits shop, we've built
                  our reputation on quality products, knowledgeable service, and a genuine passion
                  for aquatic life. Our team brings decades of combined experience in aquarium
                  keeping and aquatic animal care.
                </p>
                <p>
                  We believe that every aquarium tells a story, and we're here to help you create
                  yours. Whether you're setting up your first tank or expanding an existing collection,
                  Ocean Wings Aquarium is your partner in creating beautiful underwater worlds.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Our Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="shadow-card hover:shadow-ocean transition-smooth">
                <CardContent className="pt-6 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                    <value.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">500+</div>
              <p className="text-muted-foreground">Happy Customers</p>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">200+</div>
              <p className="text-muted-foreground">Fish Species</p>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">1000+</div>
              <p className="text-muted-foreground">Products</p>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">5+</div>
              <p className="text-muted-foreground">Years Experience</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default About;
